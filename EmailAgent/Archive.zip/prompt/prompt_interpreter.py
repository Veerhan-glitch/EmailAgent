"""
S0: Prompt Interpretation
Converts user natural language command into structured agent instructions
"""

import logging
import json
from typing import Dict, Any

from config import Config

# Gemini SDK
from google import genai

logger = logging.getLogger(__name__)
def _safe_int(value, default):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


class PromptInterpreter:
    """Interprets user prompt into scope + actions"""

    def __init__(self):
        self.use_gemini = Config.GEMINI_ENABLED and bool(Config.GEMINI_API_KEY)

        self.gemini_client = None
        if self.use_gemini:
            try:
                self.gemini_client = genai.Client(api_key=Config.GEMINI_API_KEY)
            except Exception as e:
                logger.error(f"Failed to initialize Gemini client: {e}")
                self.use_gemini = False

    def interpret(self, user_prompt: str) -> Dict[str, Any]:
        """
        Interpret user command into structured plan.
        Always returns a valid plan using:
        Gemini → safe defaults
        """
        logger.info(f"Interpreting user prompt: {user_prompt}")

        plan: Dict[str, Any] = {}

        # 1️⃣ Gemini interpretation (minimal prompt)
        if self.use_gemini:
            try:
                context = self._build_context(user_prompt)
                plan = self._interpret_with_gemini(context)
            except Exception as e:
                logger.error(f"Gemini prompt interpretation failed: {e}")
                plan = {}
        if plan:
            plan = self._repair_plan(plan)

        # 2️⃣ Fallback defaults (ALWAYS)
        if not plan:
            logger.warning("Using fallback interpretation defaults")
            plan = self._default_plan()

        logger.info(f"✓ Interpreted plan: {plan}")
        return plan

    # ------------------------------------------------------------------
    # Gemini interpretation (INTENTIONALLY LOW TOKEN)
    # ------------------------------------------------------------------

    def _interpret_with_gemini(self, context: str) -> Dict[str, Any]:
        if not self.gemini_client:
            return {}

        response = self.gemini_client.models.generate_content(
            model=Config.GEMINI_MODEL,
            contents=context
        )

        raw_text = None
        if hasattr(response, "text") and response.text:
            raw_text = response.text
        else:
            try:
                raw_text = response.output[0].content[0].text
            except Exception:
                raw_text = None

        if not raw_text:
            return {}

        try:
            return json.loads(raw_text)
        except json.JSONDecodeError:
            logger.error("Gemini returned invalid JSON")
            return {}

    # ------------------------------------------------------------------
    # Prompt builder (STRICT JSON)
    # ------------------------------------------------------------------

    def _build_context(self, user_prompt: str) -> str:
        """
        Very strict JSON-only prompt.
        """
        return (
            "Convert the user request into STRICT JSON only.\n\n"
            "JSON schema:\n"
            "{\n"
            '  "scope": {\n'
            '    "time_range_days": number,\n'
            '    "max_results": number,\n'
            '    "query": string\n'
            "  },\n"
            '  "actions": {\n'
            '    "draft_replies": boolean,\n'
            '    "require_approval": boolean,\n'
            '    "only_urgent": boolean,\n'
            '    "include_followups": boolean\n'
            "  },\n"
            '   "target": {\n'
            '     "sender_email": string,\n'
            '     "latest_only": boolean\n'
            '   }\n'
            "}\n\n"
            "Rules:\n"
            "- Output valid JSON only\n"
            "- No explanations\n"
            "- No markdown\n"
            "- If user says 'summarize', 'tell me', or 'show', do NOT draft replies\n"
            "- 'summarize 1 email' means max_results = 1\n"
            "- 'important' implies only_urgent = true\n"
            "- If user says \"reply to <email>\", extract sender_email\n"
            "- If user says \"latest\", set latest_only = true\n"
            "- Make reasonable defaults if unclear\n\n"
            "- Reply actions ALWAYS require confirmation\n"
            f"User request:\n{user_prompt}\n\n"
            "JSON:"
        )

    # ------------------------------------------------------------------
    # Safe fallback (NEVER FAIL)
    # ------------------------------------------------------------------

    def _default_plan(self) -> Dict[str, Any]:
        return {
            "scope": {
                "time_range_days": 1,
                "max_results": Config.MAX_EMAILS_TO_PROCESS,
                "query": ""
            },
            "actions": {
                "draft_replies": False,
                "require_approval": True,
                "only_urgent": False,
                "include_followups": False
            }
        }
    def _repair_plan(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        scope = raw.get("scope", {}) or {}
        actions = raw.get("actions", {}) or {}
        target = raw.get("target", {}) or {}

        return {
            "scope": {
                "time_range_days": _safe_int(scope.get("time_range_days"), 3),
                "max_results": _safe_int(scope.get("max_results"), 5),
                "query": scope.get("query") or "",
            },
            "actions": {
                "draft_replies": bool(actions.get("draft_replies", False)),
                "require_approval": True,   # force human-in-loop
                "only_urgent": bool(actions.get("only_urgent", False)),
                "include_followups": bool(actions.get("include_followups", False)),
            },
            "target": {
                "sender_email": target.get("sender_email"),
                "latest_only": bool(target.get("latest_only", True))
            }
        }
