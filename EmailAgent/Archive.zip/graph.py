import logging
import uuid
from typing import TypedDict, Dict, Any, Optional
from datetime import datetime

from langgraph.graph import StateGraph, END

from email_agent import EmailAgent
from models import ProcessingBatch

# --------------------------------------------------
# Logging
# --------------------------------------------------

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# --------------------------------------------------
# Graph State
# --------------------------------------------------

class AgentState(TypedDict):
    batch: ProcessingBatch
    plan: Dict[str, Any]              # full interpreted plan
    action_plan: Dict[str, Any]       # derived actions only
    error: Optional[str]

# --------------------------------------------------
# Helpers
# --------------------------------------------------

def new_agent() -> EmailAgent:
    """
    Create a fresh agent per run.
    NO shared mutable state.
    """
    return EmailAgent()

# --------------------------------------------------
# Nodes
# --------------------------------------------------

def setup_node(state: AgentState) -> AgentState:
    logger.info("SETUP")
    agent = new_agent()

    try:
        agent.check_tool_permissions()
        return state
    except Exception as e:
        state["error"] = f"Setup failed: {e}"
        return state


def interpret_node(state: AgentState) -> AgentState:
    logger.info("INTERPRET")
    agent = new_agent()
    batch = state["batch"]

    try:
        plan = agent.prompt_interpreter.interpret(batch.user_command)

        state["plan"] = plan
        state["action_plan"] = plan.get("actions", {})
        batch.user_scope = plan.get("scope", {})

        logger.info(f"Scope: {batch.user_scope}")
        logger.info(f"Actions: {state['action_plan']}")

        return state

    except Exception as e:
        state["error"] = f"Interpretation failed: {e}"
        return state


def ingest_node(state: AgentState) -> AgentState:
    logger.info("INGEST")
    agent = new_agent()
    batch = state["batch"]

    try:
        raw = agent.data_ingestion(batch.user_scope)
        batch.emails = [agent.create_processed_email(m) for m in raw]

        logger.info(f"Ingested {len(batch.emails)} emails")
        return state

    except Exception as e:
        state["error"] = f"Ingestion failed: {e}"
        return state


def core_processing_node(state: AgentState) -> AgentState:
    logger.info("CORE PROCESSING")
    agent = new_agent()
    batch = state["batch"]

    for email in batch.emails:
        agent.process_email_core_pipeline(email)

    return state


def edge_cases_node(state: AgentState) -> AgentState:
    logger.info("EDGE CASES")
    agent = new_agent()
    agent.handle_edge_cases(state["batch"])
    return state


def pre_draft_policy_node(state: AgentState) -> AgentState:
    """
    Blocks drafting if intent is unclear or risky.
    """
    logger.info("PRE-DRAFT POLICY")
    agent = new_agent()

    for email in state["batch"].emails:
        agent.apply_pre_draft_policy(email)

    return state


def drafting_node(state: AgentState) -> AgentState:
    logger.info("DRAFTING")
    agent = new_agent()
    batch = state["batch"]

    for email in batch.emails:
        if not email.is_blocked:
            agent.draft_replies(email)

    return state


def post_draft_guardrails_node(state: AgentState) -> AgentState:
    logger.info("POST-DRAFT GUARDRAILS")
    agent = new_agent()

    for email in state["batch"].emails:
        agent.apply_guardrails(email)

    return state


def finalize_node(state: AgentState) -> AgentState:
    logger.info("FINALIZE")
    agent = new_agent()
    batch = state["batch"]

    batch.completed_at = datetime.utcnow()
    batch.total_processed = len(batch.emails)

    agent.generate_final_output(batch)
    return state


def error_node(state: AgentState) -> AgentState:
    logger.error(f"ERROR: {state['error']}")
    return state

# --------------------------------------------------
# Routing
# --------------------------------------------------

def has_error(state: AgentState):
    return "error" if state.get("error") else "continue"


def empty_inbox(state: AgentState):
    return "finalize" if not state["batch"].emails else "continue"

# --------------------------------------------------
# Graph Builder
# --------------------------------------------------

def build_graph():
    g = StateGraph(AgentState)

    g.add_node("setup", setup_node)
    g.add_node("interpret", interpret_node)
    g.add_node("ingest", ingest_node)
    g.add_node("core", core_processing_node)
    g.add_node("edges", edge_cases_node)
    g.add_node("pre_draft_policy", pre_draft_policy_node)
    g.add_node("drafting", drafting_node)
    g.add_node("guardrails", post_draft_guardrails_node)
    g.add_node("finalize", finalize_node)
    g.add_node("error", error_node)

    g.set_entry_point("setup")

    g.add_edge("setup", "interpret")

    g.add_conditional_edges(
        "interpret",
        has_error,
        {
            "error": "error",
            "continue": "ingest",
        },
    )

    g.add_conditional_edges(
        "ingest",
        empty_inbox,
        {
            "finalize": "finalize",
            "continue": "core",
        },
    )

    g.add_edge("core", "edges")
    g.add_edge("edges", "pre_draft_policy")
    g.add_edge("pre_draft_policy", "drafting")
    g.add_edge("drafting", "guardrails")
    g.add_edge("guardrails", "finalize")

    g.add_edge("finalize", END)
    g.add_edge("error", END)

    return g.compile()

# --------------------------------------------------
# Runner
# --------------------------------------------------

def run_agent_graph(user_prompt: str):
    app = build_graph()

    batch = ProcessingBatch(
        batch_id=str(uuid.uuid4())[:8],
        user_command=user_prompt,
        user_scope={},
    )

    state: AgentState = {
        "batch": batch,
        "plan": {},
        "action_plan": {},
        "error": None,
    }

    logger.info(f"Starting batch {batch.batch_id}")
    app.invoke(state)
    logger.info("Done.")


if __name__ == "__main__":
    prompt = input("\n🧠 What should I do with your inbox?\n> ")
    run_agent_graph(prompt)
